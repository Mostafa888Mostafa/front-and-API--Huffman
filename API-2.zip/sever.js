const express = require('express');
const {spawn} = require('child_process');
const app = express();
const port = 3000;
// Require the upload middleware
const uploadFile = require('./uploadFile');
// Add headers before the routes are defined
app.use('/public', express.static('public'))
app.use(function (req, res, next) {

  // Website you wish to allow to connect
  res.setHeader('Access-Control-Allow-Origin', '*');

  // Request methods you wish to allow
  res.setHeader('Access-Control-Allow-Methods', 'GET, POST, OPTIONS, PUT, PATCH, DELETE');

  // Request headers you wish to allow
  res.setHeader('Access-Control-Allow-Headers', 'X-Requested-With,content-type');

  // Set to true if you need the website to include cookies in the requests sent
  // to the API (e.g. in case you use sessions)

  // Pass to next layer of middleware
  next();
});
// Set up a route for file uploads
app.post('/uploadFile/:name', uploadFile.single('file'),(req, res) => {
  res.header("Access-Control-Allow-Origin", "*")
  const getPythonScriptStdout = (pythonScriptPath) => {
    const python = spawn('python3', ['H.py', req.params.name]);
    return new Promise((resolve, reject) => {
        let result = ""
        python.stdout.on('data', (data) => {
            result += data
        });
        python.on('close', () => {
            resolve(result)
        });
        python.on('error', (err) => {
            reject(err)
        });
    })
}
        // Handle the uploaded file
        
        // collect data from script
  getPythonScriptStdout('./python.py').then((output) => {
    res.status(200).json(output.replace('\n', '').replace('\r', ''));
          console.log(output.replace('\n', '').replace('\r', ''))
      })
          
});


app.listen(port, () => {
  console.log(`Server is running on port ${port}`);
});
``