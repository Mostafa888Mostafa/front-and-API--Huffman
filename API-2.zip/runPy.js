const {spawn} = require('child_process');
  console.log('hi')
  const python = spawn('python', ['python/H.py', file]);
  console.log(file)
  // collect data from script
  python.stdout.on('data', function (data) {
   console.log('Pipe data from python script ...');
    dataToSend = data.toString();
    console.log(dataToSend)
  });
  // in close event we are sure that stream from child process is closed
  python.on('close', (code) => {
  console.log(`child process close all stdio with code ${code}`);
  return
  });
module.exports = runPyCode;